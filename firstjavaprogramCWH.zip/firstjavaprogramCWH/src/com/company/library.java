//You have to implement a library using java class "Library"
//Method:addbook,issuebook,returnbook,showavaliablebook;
//properties:Array to store the avalble books;
//array to store the issued book
package com.company;
class Library{
    String[] books;
    int no_of_books;
    Library(){
    this.books=new String[100];
    this.no_of_books=0;
    }
    void add_book(String book){
        this.books[no_of_books]=book;
        no_of_books++;
        System.out.println(book+"book has been added");
    }
    void Show_available_books(){
        System.out.println("Available books are");
        for (String book:this.books)
        {
            continue;
        }
        System.out.println("*"+books);
    }
    void issue_book(String book){
        for (int i=0;i<this.books.length;i++)
        {
            if(this.books[i].equals(book))
            System.out.println("Issued");
            this.books[i]=null;
        }
        System.out.println("not exist");
    }
    void returnbook(String book){
        add_book(book);
    }

}
public class library {
    public static void main(String[] args) {
        Library CentralLibrary=new Library();
        CentralLibrary.add_book("c++");
        CentralLibrary.Show_available_books();


    }
}