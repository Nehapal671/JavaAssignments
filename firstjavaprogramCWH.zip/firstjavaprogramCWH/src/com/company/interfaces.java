package com.company;
interface bicycle{
    void apply_brakes(int decrement);
    void speedup(int increment);
    int a=45;
}//we can make more than one interface and implements it in
interface horn{
    void horn1();
}
 class avon_cycle implements bicycle,horn{
    void blow_horn(){
        System.out.println("pii poo pii");
    }
     public void speedup(int increment) {
         System.out.println("break");
     }
     public void apply_brakes(int decrement){
         System.out.println("Apply_brakes");
    }
    public void horn1()
     {
         System.out.println("pii");
     }
 }
public class interfaces {
    public static void main(String[] args) {
        avon_cycle c=new avon_cycle();
        c.apply_brakes(3);
        //u can properties in interface
        //u can not modify properties
        System.out.println(c.a);
        c.horn1();
        c.blow_horn();
//        c.apply_brakes(4);

    }
}
