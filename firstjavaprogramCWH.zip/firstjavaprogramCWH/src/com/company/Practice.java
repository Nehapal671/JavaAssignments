package com.company;
class circle{
    public int r;
    circle(int r){
        this.r=r;
    }
    public void area(){
        System.out.println(  (Math.PI*this.r*this.r));
    }
}
class cylinder extends circle{
    public int H;
    cylinder(int r,int H){
        super(r);
        this.H=H;
    }
    void volume(){
        System.out.println(Math.PI*this.r*this.r*this.H);}
}
public class Practice {
    public static void main(String[] args) {
        //Problem1
//        circle obj=new circle(12);
        cylinder c1=new cylinder(5 ,7);
    c1.volume();
    c1.area();

    }
}
