package com.company;


public class accessModifier {
    public static void main(String[] args) {

    }
}
