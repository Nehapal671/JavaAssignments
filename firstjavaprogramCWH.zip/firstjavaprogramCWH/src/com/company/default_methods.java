package com.company;
interface camera{
    void snap();
    void take_video();
}
interface media{
    void listen_music();
    void save_playlist();
}
interface GPS{
    void find_dis();
    default void defaulties(){
        System.out.println("Mai default hu or default keyword ka use krr ke khi bhi lagaya ja skta hu or mujhe yhi define krna padega.");
    }
}
interface Wifi{
    String[] getNetwork();
}
class cellphone{
    void callNumber(int phoneNumber){
        System.out.println("calling...."+phoneNumber);
    }
    void pickcall(){
        System.out.println("hello..");
    }
}
class Smartphone extends cellphone implements Wifi,camera,media,GPS{
    public void snap(){
        System.out.println("Take snap..Click");
    }
    public void take_video(){
        System.out.println("Shoot a vedio....");
    }
    public void listen_music(){
        System.out.println("Listening music......");
    }
    public void save_playlist(){
        System.out.println("Save your favorite songs....");
    }
    public void find_dis(){
        System.out.println("Find a suitable way....");
    }
    public String[] getNetwork(){
        System.out.println("Network list");
        String[] network_list={"Redmi Note 9 pro","JCN_Harish","Vivek_/Rana"};
        return network_list;
    }
}
public class default_methods {
    public static void main(String[] args)
    {
        Smartphone s= new Smartphone();
        String[] a=s.getNetwork();
        for (String item:a)
        {
            System.out.println(item);
        }
        s.find_dis();
        s.defaulties();

    }
}
