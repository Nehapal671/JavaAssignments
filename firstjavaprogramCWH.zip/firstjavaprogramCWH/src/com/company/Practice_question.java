package com.company;
abstract class pen{
    abstract void write();
    abstract void refill();
}
class fountain_pen extends pen{
    void change_nib(){
        System.out.println("change the nib..");
    }
    void write() {
        System.out.println("write from me...");
    }
    void refill(){
        System.out.println("refill it..");
    }
}
class Monkey{
    void jump(){
        System.out.println("jumping..");
    }
    void bite(){
        System.out.println("khau khau...");
    }
}
interface basic_Animal{
    void eat();
    void sleep();
}
class human extends Monkey implements basic_Animal{
    void speak(){
        System.out.println("hii.");
    }
    public void eat(){
        System.out.println("eating..");
    }
    public void sleep(){
        System.out.println("sleeping..");
    }
}
abstract class Telephone{
    abstract void ring();
    abstract void lift();
    abstract void disconnect();
}
 class smartphone extends Telephone{
    void cam(){
        System.out.println("its a cam also");
    }
     void ring(){
        System.out.println("Ringing...");
    }
    void lift(){
        System.out.println("lifting...");
    }
     void disconnect(){
        System.out.println("disconnected...");
    }
}
public class Practice_question
{
    public static void main(String[] args) {
        fountain_pen pen = new fountain_pen();
        pen.change_nib();//q1
        human h = new human();
        h.sleep();//q2
        Monkey m = new human();
//        m.speak();-->cant use speak because reference is monkey which does nt hav speak method;
        basic_Animal b = new human();
        b.eat();
        b.sleep();
        Telephone t= new smartphone() ;
        t.disconnect();
      //  t.cam(); show polymorphism
    }
}
