package com.company;
import java.util.Scanner;

//class c_class{
//    int x=6,y=9;
//    void multiplication(){
//        int n;
//        n=x*y;
//        System.out.println("The Multiplication  of"+ x +" "+"and"+ y +" "+"is " + n);
//    }
//}
public class classs  {
    static void add(){
        int t,x=8,y=9;
        t= x + y;
        System.out.println("The Add  of"+ x +" "+"and"+ y +" "+"is " + t);
    }
    static void add(int t){
        int x=8,y=9;
        t= x + y;
        System.out.println("The Add  of"+ x +" "+"and"+ y +" "+"is " + t);
    }
    public static void main(String[] args) {
//        classs c= new classs();
//        c.multiplication();
        add();
    }
}
